WMO Climatological Standard Normals, 1991-2020, Readme

A total of 141 countries across the six World Meteorological Organization (WMO) Regions submitted
1991-2020 Climatological Standard Normals in response to a decadal request from the WMO. The World
Data Service for Meteorology at NCEI worked with representatives of the WMO to collect and quality
control the submissions.

Countries were asked to submit their 1991-2020 Normals data in either Excel or Comma Separated
Values (CSV) formats. NCEI converted all Excel station files into individual CSV files (one for each
station), so there is one CSV file for every station, while Excel files are not universally available. The total
number of CSV station files is 6818.

Information regarding the contributions of each country is included in one of six explanatory
information documents.

./documents/
Explanatory_Information_Region1.pdf
Explanatory_Information_Region2.pdf
Explanatory_Information_Region3.pdf
Explanatory_Information_Region4.pdf
Explanatory_Information_Region5.pdf
Explanatory_Information_Region6.pdf

As updates and additions to the 1991-2020 Normals data are made, new releases are provided. Changes
and updates made in each release are annotated in the Status_and_Updates file located in the
documents directory.

./documents/
Status_and_Updates_9120.pdf

There are 8 Primary Parameters as well as Secondary and ‘Other’ optional parameters. A description of
each Parameter and the format of the Excel and CSV files is provided in
./documents/WMO_Normals_9120_Format_and_Parameters.pdf

The number of countries providing 1991-2020 Normals data within each Region is as follows.

Region I: 30
Region II: 26
Region III: 11
Region IV: 20
Region V: 13
Region VI: 42

The number of station files available for each of the 141 corresponding countries is provided in the file
./metadata/country_station_counts.csv. Note that the Russian Federation has stations in both Region II
and Region VI.
The 1991-2020 Normals files for each country are provided within a subdirectory for the respective
region. Within each Region subdirectory there are directories for each corresponding country.
./Region_1_WMO_Normals_9120/
..
./Region_6_WMO_Normals_9120/

A list of all Excel and CSV Normals files within the six regions is provided in
./documents/WMO_Normals_1991-2020_Country_and_StationFiles.pdf
________________________________________________________________________

In addition to the individual Normals files for each station, composite files containing the primary
parameter data for all countries are provided in a CSV file for each of the primary parameters.

./data_composite_primary_parameters/
●       wmo_normals_9120_PRCP.csv
●       wmo_normals_9120_DP01.csv
●       wmo_normals_9120_TMAX.csv
●       wmo_normals_9120_TMIN.csv
●       wmo_normals_9120_TAVG.csv
●       wmo_normals_9120_MSLP.csv
●       wmo_normals_9120_MNVP.csv
●       wmo_normals_9120_TSUN.csv

These Primary parameter data are provided in CSV files with the following format. Note that although
the latitude/longitude of each station is provided as Degrees/Minutes/Seconds in each station Normals
files, the locations were converted and provided as decimal degrees in these files.

    •   Elem: Element number from 1 to 8.
    •   Region: Regions 1 to 6.
    •   ID: An 8-digit identifier. For stations with a legacy WMO number the 5-digit WMO number is
        preceded by ‘000’.
    •   WIGOS_ID: WMO Integrated Global Observing System (WIGOS) Identifier.
    •   Latitude: Latitude of the station (Decimal degrees)
    •   Longitude: Longitude of the station (Decimal degrees)
    •   Elevation: Elevation of the station (Meters)
    •   Country: Country providing the station data
    •   Station: Name of the station
    •   Data (13): 12 monthly and 1 annual Normals value

________________________________________________________________________

A set of composite data files for each of the eight (8) primary parameters also is provided for those
Normals values computed with at least 24 years of data in the 30-year period. Parameters for which the
number of years were not provided are assumed to have been computed using 30 years of data.
./data_composite_primary_parameters_min24/
wmo_normals_9120_DP01_min24.csv
wmo_normals_9120_MNVP_min24.csv
wmo_normals_9120_MSLP_min24.csv
wmo_normals_9120_PRCP_min24.csv
wmo_normals_9120_TAVG_min24.csv
wmo_normals_9120_TMAX_min24.csv
wmo_normals_9120_TMIN_min24.csv
wmo_normals_9120_TSUN_min24.csv

These files are formatted in the same way as the set of full composite files described above.

_________________________________________________________________________

A metadata file containing a list of each station and the primary parameters that are available for each is
provided in ./metadata/wmo_normals_9120_8param_meta.csv

_________________________________________________________________________

In addition there is a metadata file specific to each of the eight (8) primary parameters.
./metadata/
wmo_normals_9120_DP01_meta.csv
wmo_normals_9120_MNVP_meta.csv
wmo_normals_9120_MSLP_meta.csv
wmo_normals_9120_PRCP_meta.csv
wmo_normals_9120_TAVG_meta.csv
wmo_normals_9120_TMAX_meta.csv
wmo_normals_9120_TMIN_meta.csv
wmo_normals_9120_TSUN_meta.csv

These files are formatted as follows:
   • Elem: Element number from 1 to 8.
   • Region: Regions 1 to 6.
   • Country: Country providing the station data
   • Latitude: Latitude of the station (Decimal degrees)
   • Longitude: Longitude of the station (Decimal degrees)
   • Filename: Station filename for the Comma Separated Values file.

______________________________________________________________________

A set of global maps depicting the Normals values for each set of Monthly and Annual Primary
parameters is provided.
./maps_global_primary_parameters/

   ●   PRCP (Precipitation, millimeters, mm)
          ○ map-norms9120-PRCP-1.jpg
          ○ ..
          ○ map-norms9120-PRCP-13.jpg
   ●   DP01 (Number of Days per Month/Annual with at least 1 millimeter of precipitation, #Days)
          ○ map-norms9120-DP01-1.jpg
          ○ ..
          ○ map-norms9120-DP01-13.jpg
   ●   TMAX (Mean Maximum Temperature, Degrees Celsius, degC)
          ○ map-norms9120-TMAX-1.jpg
          ○ ..
          ○ map-norms9120-TMAX-13.jpg
   ●   TMIN (Mean Minimum Temperature, Degrees Celsius, degC)
          ○ map-norms9120-TMIN-1.jpg
          ○ ..
          ○ map-norms9120-TMIN-13.jpg
   ●   TAVG (Mean Temperature, Degrees Celsius, degC)
          ○ map-norms9120-TAVG-1.jpg
          ○ ..
          ○ map-norms9120-TAVG-13.jpg
   ●   MSLP (Mean Sea Level Pressure, Hectopascal, hPa)
          ○ map-norms9120-MSLP-1.jpg
          ○ ..
          ○ map-norms9120-MSLP-13.jpg
   ●   MNVP (Mean Vapor Pressure, Hectopascal, hPa)
          ○ map-norms9120-MNVP-1.jpg
          ○ ..
          ○ map-norms9120-MNVP-13.jpg
   ●   TSUN (Total Sunshine, Number of Hours per Month/Annual of sunshine, Hours)
          ○ map-norms9120-TSUN-1.jpg
          ○ ..
          ○ map-norms9120-TSUN-13.jpg

______________________________________________________________________

The same set of global maps described above also is provided using a color palette that should be more
accessible for color blind individuals.

./maps_global_primary_parameters-cb/
